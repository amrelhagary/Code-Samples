This AngularJS App is small clone of Jira issue tracker
- manage sprints
- manage users
- assign tasks
- show estimation