<?php
var_dump($_SERVER['REQUEST_URI']);