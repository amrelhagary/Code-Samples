<?php
return array(
		
		"plz" => "برجاء إدخال",
		// ..//src/Listing/Controller/IndexController.php:1255
		"Try Again later." => "برجاء إعادة المحاولة.",
		// ..//src/Listing/Controller/IndexController.php:1299
		// ..//src/Listing/Controller/SurveyController.php:108
		"valid" => "صحيح",
		// ..//src/Listing/Controller/IndexController.php:1299
		// ..//src/Listing/Controller/SurveyController.php:108
		"code" => "الكود",
		// ..//src/Listing/Controller/IndexController.php:1299
		// ..//src/Listing/Controller/SurveyController.php:108
		"shown" => ".الظاهر أدناه",
		// ..//src/Listing/Controller/IndexController.php:1806
		// ..//src/Listing/Form/AddIncorrectDataReportForm.php:21
		"Telephone number" => "رقم التليفون",
		// ..//src/Listing/Controller/IndexController.php:1808
		// ..//src/Listing/Form/AddIncorrectDataReportForm.php:28
		"Address" => "العنوان",
		// ..//src/Listing/Controller/IndexController.php:1810
		// ..//src/Listing/Form/AddIncorrectDataReportForm.php:35
		"Company Name" => "اسم الشركة",
		// ..//src/Listing/Controller/IndexController.php:1812
		// ..//src/Listing/Form/AddIncorrectDataReportForm.php:42
		"Website" => "الموقع الإلكتروني",
		// ..//src/Listing/Controller/IndexController.php:1814
		// ..//src/Listing/Form/AddIncorrectDataReportForm.php:49
		"Map" => "الموقع على الخريطة",
		// ..//src/Listing/Controller/IndexController.php:1816
		"Closed" => "اغلق",
		// ..//src/Listing/Controller/IndexController.php:1818
		// ..//src/Listing/Form/AddIncorrectDataReportForm.php:63
		// ..//src/Listing/Form/AddRatingNewForm.php:30
		"Other" => "أخري",
		// ..//src/Listing/Controller/IndexController.php:1820
		// ..//view/listing/index/add-incorrect-data-report.phtml:112
		"You should select one at least." => "لا بد ان تختار سبب واحد علي الاقل",
		// ..//src/Listing/Controller/IndexController.php:1838
		"Added Successfully" => "تم الارسال بنجاح.",
		// ..//src/Listing/Controller/IndexController.php:1840
		"Operation Failed" => "لم تنجح العملية",
		// ..//src/Listing/Controller/SurveyController.php:94
		"emailalert" => "برجاء إدخال عنوان بريد اليكتروني صحيح.",
		// ..//src/Listing/Controller/SurveyController.php:101
		"plz_reg" => "برجاء اختيار السبب.",
		// ..//src/Listing/Controller/SurveyController.php:119
		"rate_sent_succ" => "شكرا لتواصلك معنا! سوف نجيب عن أي استفسارات وردتْ برسالتك، في أقرب فرصة.يسرنا دائما تلقي تعليقاتكم ومقترحاتكم.",
		// ..//src/Listing/Form/AddIncorrectDataReportForm.php:56
		"Business is closed" => "تم إغلاق الشركة",
		// ..//src/Listing/Form/AddIncorrectDataReportForm.php:70
		"",
		"If you have anything else you would like to let us know about, please do right here:" => "إذا كان لديك أي شيء آخر تريد إعلامنا به؟ برجاء إضافته هنا:",
		// ..//src/Listing/Form/AddIncorrectDataReportForm.php:75
		// ..//src/Listing/Form/AddRatingNewForm.php:129
		"submit" => "ارسال",
		// ..//src/Listing/Form/AddRatingNewForm.php:25
		"Today, I was searching on Yellow.com.eg for:" => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:26
		// ..//src/Listing/Form/AddRatingNewForm.php:39
		// ..//src/Listing/Form/AddRatingNewForm.php:52
		// ..//src/Listing/Form/AddRatingNewForm.php:65
		// ..//src/Listing/Form/AddRatingNewForm.php:78
		// ..//src/Listing/Form/AddRatingNewForm.php:91
		// ..//src/Listing/Form/AddRatingNewForm.php:104
		"1" => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:26
		"A product (e.g. Air Conditioners, Cars, TVs...)" => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:27
		// ..//src/Listing/Form/AddRatingNewForm.php:40
		// ..//src/Listing/Form/AddRatingNewForm.php:53
		// ..//src/Listing/Form/AddRatingNewForm.php:66
		// ..//src/Listing/Form/AddRatingNewForm.php:79
		// ..//src/Listing/Form/AddRatingNewForm.php:92
		// ..//src/Listing/Form/AddRatingNewForm.php:105
		"2" => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:27
		"A service (e.g. Food Delivery, Car Rentals, Advertising Agencies...)" => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:28
		// ..//src/Listing/Form/AddRatingNewForm.php:41
		// ..//src/Listing/Form/AddRatingNewForm.php:54
		// ..//src/Listing/Form/AddRatingNewForm.php:67
		// ..//src/Listing/Form/AddRatingNewForm.php:80
		// ..//src/Listing/Form/AddRatingNewForm.php:93
		// ..//src/Listing/Form/AddRatingNewForm.php:106
		"3" => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:28
		"A brand (e.g. Nokia, Toyota, Nike ...)" => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:29
		// ..//src/Listing/Form/AddRatingNewForm.php:42
		// ..//src/Listing/Form/AddRatingNewForm.php:55
		// ..//src/Listing/Form/AddRatingNewForm.php:68
		// ..//src/Listing/Form/AddRatingNewForm.php:81
		// ..//src/Listing/Form/AddRatingNewForm.php:94
		// ..//src/Listing/Form/AddRatingNewForm.php:107
		"4" => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:29
		"A business or Company Name (e.g. Mobinil, AUC, Andrea’s Restaurant...)" => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:30
		// ..//src/Listing/Form/AddRatingNewForm.php:43
		// ..//src/Listing/Form/AddRatingNewForm.php:56
		// ..//src/Listing/Form/AddRatingNewForm.php:69
		// ..//src/Listing/Form/AddRatingNewForm.php:82
		// ..//src/Listing/Form/AddRatingNewForm.php:95
		// ..//src/Listing/Form/AddRatingNewForm.php:108
		"5" => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:38
		"Overall, my experience on Yellow.com.eg was good. " => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:39
		// ..//src/Listing/Form/AddRatingNewForm.php:52
		// ..//src/Listing/Form/AddRatingNewForm.php:65
		// ..//src/Listing/Form/AddRatingNewForm.php:78
		// ..//src/Listing/Form/AddRatingNewForm.php:91
		// ..//src/Listing/Form/AddRatingNewForm.php:104
		"Strongly Agree" => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:40
		// ..//src/Listing/Form/AddRatingNewForm.php:53
		// ..//src/Listing/Form/AddRatingNewForm.php:66
		// ..//src/Listing/Form/AddRatingNewForm.php:79
		// ..//src/Listing/Form/AddRatingNewForm.php:92
		// ..//src/Listing/Form/AddRatingNewForm.php:105
		"Agree" => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:41
		// ..//src/Listing/Form/AddRatingNewForm.php:54
		// ..//src/Listing/Form/AddRatingNewForm.php:67
		// ..//src/Listing/Form/AddRatingNewForm.php:80
		// ..//src/Listing/Form/AddRatingNewForm.php:93
		// ..//src/Listing/Form/AddRatingNewForm.php:106
		"Neutral" => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:42
		// ..//src/Listing/Form/AddRatingNewForm.php:55
		// ..//src/Listing/Form/AddRatingNewForm.php:68
		// ..//src/Listing/Form/AddRatingNewForm.php:81
		// ..//src/Listing/Form/AddRatingNewForm.php:94
		// ..//src/Listing/Form/AddRatingNewForm.php:107
		"Disagree" => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:43
		// ..//src/Listing/Form/AddRatingNewForm.php:56
		// ..//src/Listing/Form/AddRatingNewForm.php:69
		// ..//src/Listing/Form/AddRatingNewForm.php:82
		// ..//src/Listing/Form/AddRatingNewForm.php:95
		// ..//src/Listing/Form/AddRatingNewForm.php:108
		"Strongly Disagree" => "",
		"was easy to find what I was looking for on Yellow.com.eg." => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:64
		"I will take the next step and contact the company I found on Yellow.com.eg today or within one week." => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:77
		"The number of companies I'll contact from those I found on Yellow.com.eg are:" => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:90
		"When I'm searching for a business on Yellow.com.eg, it is important to me that the companies I look at have (check all that apply):" => "",
		// ..//src/Listing/Form/AddRatingNewForm.php:103
		"In continuation of the above question, I would rarely contact a company if it only provides a phone number without any other information about it." => "",
		// ..//src/Listing/Helper/AlsoServing.php:26
		// ..//src/Listing/Helper/AlsoServing.php:30
		"also_serving" => "...وأيضاً يخدم منطقة",
		// ..//src/Listing/Helper/AreaBox.php:87
		// ..//view/listing/index/character-bar-search.phtml:14
		// ..//view/listing/index/character-bar.phtml:14
		// ..//view/listing/index/search-form.phtml:21
		// ..//view/listing/index/search-form.phtml:23
		"all" => "جميع المدن",
		// ..//src/Listing/Helper/AreaBox.php:103
		"close" => "أغلق",
		// ..//src/Listing/Helper/AreaBox.php:107
		// ..//view/listing/index/search.phtml:77
		"more" => "<< المزيد",
		// ..//src/Listing/Helper/CompanyAddress.php:58
		// ..//view/listing/index/ksa_search.phtml:110
		// ..//view/listing/index/ksa_search.phtml:238
		"landmark" => "علامة مميزة",
		// ..//src/Listing/Helper/CompanyContacts.php:76
		"companyphone" => "التليفون",
		// ..//src/Listing/Helper/CompanyContacts.php:79
		"fax" => "الفاكس",
		// ..//src/Listing/Helper/CompanyContacts.php:82
		"phoneFax" => "تليفاكس",
		// ..//src/Listing/Helper/CompanyOpeningHours.php:49
		"Open 24/7" => "مفتوح 24/7",
		// ..//src/Listing/Helper/CompanyServices.php:38
		// ..//src/Listing/Helper/ServicesBar.php:75
		"photoicon" => "صورة الشركة",
		// ..//src/Listing/Helper/CompanyServices.php:44
		"reviews" => "تقييمات وآراء",
		// ..//src/Listing/Helper/CompanyServices.php:54
		// ..//src/Listing/Helper/ServicesBar.php:67
		"videoicon" => "فيديو",
		// ..//src/Listing/Helper/CompanyServices.php:60
		// ..//src/Listing/Helper/ServicesBar.php:71
		"profileicon" => "نبذة عن الشركة",
		// ..//src/Listing/Helper/CompanyServices.php:66
		// ..//src/Listing/Helper/ServicesBar.php:79
		"adicon" => "إعلان",
		// ..//src/Listing/Helper/CompanyServices.php:78
		// ..//src/Listing/Helper/ServicesBar.php:63
		"brandicon" => "العلامة التجارية",
		// ..//src/Listing/Helper/CompanyServices.php:84
		"menuicon" => "قائمة الطعام",
		// ..//src/Listing/Helper/CompanyServices.php:90
		// ..//view/listing/index/profile.phtml:392
		"our_restaurants" => "مطاعمنا",
		// ..//src/Listing/Helper/ServicesBar.php:47
		"qricon" => "رمز الـ QR",
		// ..//src/Listing/Helper/ServicesBar.php:51
		"emailicon" => "البريد الإلكتروني",
		// ..//src/Listing/Helper/ServicesBar.php:55
		"websiteicon" => "الموقع الإلكتروني",
		// ..//src/Listing/Helper/ServicesBar.php:59
		"branchicon" => "الفروع",
		// ..//src/Listing/Helper/SocialLinks.php:36
		"My \".tel\" Page" => "صفحتى على الـ .tel",
		// ..//src/Listing/Helper/SocialLinks.php:39
		// ..//src/Listing/Helper/SocialLinks.php:42
		"My \"Facebook\" Page" => "صفحتى على الـ Facebook",
		// ..//src/Listing/Helper/SocialLinks.php:45
		"Follow us on Twitter" => "اتبعني على Twitter",
		// ..//src/Listing/Helper/SocialLinks.php:48
		"Follow us on Google+" => "اتبعنا على Google+",
		// ..//src/Listing/Helper/SocialLinks.php:51
		"My \"Linked In\" Page" => "صفحتى على الـ Linked In",
		// ..//src/Listing/Helper/SocialLinks.php:54
		"My Video Link on YouTube" => "قناتنا على الـ  YouTube",
		// ..//src/Listing/Helper/SocialLinks.php:57
		// ..//src/Listing/Helper/SocialLinks.php:60
		"My Business Online" => "شركتى أون لاين",
		// ..//src/Listing/Helper/WorkingDaysAndHours.php:46
		"am" => "صباحا",
		// ..//src/Listing/Helper/WorkingDaysAndHours.php:48
		"pm" => "مساءا",
		// ..//view/listing/index/boxes.phtml:8
		// ..//view/listing/index/keyword-search.phtml:10
		"relatedkey" => "كلمات بحث مشابهة",
		// ..//view/listing/index/boxes.phtml:23
		// ..//view/listing/index/category-search.phtml:10
		// ..//view/listing/index/search.phtml:117
		"relatedcat" => "تصنيفات مشابهة",
		// ..//view/listing/index/boxes.phtml:39
		// ..//view/listing/index/brand-search.phtml:11
		// ..//view/listing/index/search.phtml:108
		"relatedbrands" => "كلمات بحث مشابهة",
		// ..//view/listing/index/directions.phtml:201
		"Totally Jammed" => "",
		// ..//view/listing/index/directions.phtml:205
		"Crowded" => "",
		// ..//view/listing/index/directions.phtml:209
		"Alright" => "",
		// ..//view/listing/index/directions.phtml:213
		"Great" => "",
		// ..//view/listing/index/directions.phtml:217
		"Route" => "",
		// ..//view/listing/index/ksa_search.phtml:55
		"searchresultsfor" => "نتائج البحث عن",
		// ..//view/listing/index/ksa_search.phtml:57
		"searchreturns" => "يحتوى على",
		// ..//view/listing/index/ksa_search.phtml:57
		"searchlistings" => "إدراج",
		// ..//view/listing/index/ksa_search.phtml:61
		"mapselectedlistings" => "أظهر كل النتائج على الخريطة",
		// ..//view/listing/index/ksa_search.phtml:63
		// ..//view/listing/index/ksa_search.phtml:346
		"sendSearchResult" => "شارك النتائج",
		// ..//view/listing/index/ksa_search.phtml:82
		"categorysponsor" => "راعي التصنيف",
		// ..//view/listing/index/ksa_search.phtml:84
		"keywordsponsor" => "راعي الكلمة",
		// ..//view/listing/index/ksa_search.phtml:121
		// ..//view/listing/index/ksa_search.phtml:249
		"pobox" => "صندوق البريد",
		// ..//view/listing/index/ksa_search.phtml:124
		// ..//view/listing/index/ksa_search.phtml:252
		"postalcode" => "الرمز البريدى",
		// ..//view/listing/index/ksa_search.phtml:138
		// ..//view/listing/index/ksa_search.phtml:266
		// ..//view/listing/index/search.phtml:198
		"read_more" => "... اقرا المزيد >>",
		// ..//view/listing/index/ksa_search.phtml:155
		// ..//view/listing/index/ksa_search.phtml:283
		// ..//view/listing/index/profile.phtml:69
		// ..//view/listing/index/search.phtml:285
		"categories" => "تصنيفات:",
		// ..//view/listing/index/ksa_search.phtml:167
		// ..//view/listing/index/ksa_search.phtml:295
		"updateData" => "حدث بياناتك",
		// ..//view/listing/index/ksa_search.phtml:173
		// ..//view/listing/index/ksa_search.phtml:301
		"keyword" => "كلمة البحث",
		// ..//view/listing/index/ksa_search.phtml:197
		// ..//view/listing/index/ksa_search.phtml:325
		"sendListing" => "ارسل هذه النتيجة",
		// ..//view/listing/index/profile.phtml:61
		// ..//view/listing/index/search.phtml:186
		"See All Branches" => "اعرض جميع الفروع",
		// ..//view/listing/index/profile.phtml:74
		"Payment Method" => "طرق الدفع",
		// ..//view/listing/index/profile.phtml:107
		// ..//view/listing/index/search.phtml:268
		"Order Now" => "اطلب الآن",
		// ..//view/listing/index/profile.phtml:116
		// ..//view/listing/index/profile.phtml:121
		// ..//view/listing/services/opening_hours.phtml:3
		"Sunday" => "الأحد",
		// ..//view/listing/index/profile.phtml:117
		// ..//view/listing/services/opening_hours.phtml:4
		"Monday" => "الإثنين",
		// ..//view/listing/index/profile.phtml:118
		// ..//view/listing/services/opening_hours.phtml:5
		"Tuesday" => "الثلاثاء",
		// ..//view/listing/index/profile.phtml:119
		// ..//view/listing/services/opening_hours.phtml:6
		"Wednesday" => "الأربعاء",
		// ..//view/listing/index/profile.phtml:120
		// ..//view/listing/services/opening_hours.phtml:7
		"Thursday" => "الخميس",
		// ..//view/listing/index/profile.phtml:122
		// ..//view/listing/services/opening_hours.phtml:8
		"Friday" => "الجمعه",
		// ..//view/listing/index/profile.phtml:123
		// ..//view/listing/services/opening_hours.phtml:9
		"Saturday" => "السبت",
		// ..//view/listing/index/profile.phtml:132
		// ..//view/listing/index/search.phtml:292
		"What was incorrect in the business listing" => "ما هي البيانات الغير صحيحة في هذه الشركة؟",
		// ..//view/listing/index/profile.phtml:132
		// ..//view/listing/index/search.phtml:292
		"Report incorrect data" => "أبلغ عن بيانات غير صحيحة",
		// ..//view/listing/index/profile.phtml:146
		// ..//view/listing/index/search.phtml:233
		"To Call" => "أرقام التليفون",
		// ..//view/listing/index/profile.phtml:149
		// ..//view/listing/index/search.phtml:236
		"Contact Us" => "اتصل بنا",
		// ..//view/listing/index/profile.phtml:152
		// ..//view/listing/index/search.phtml:239
		"Get Directions" => "اعرف الطريق",
		"Show Map" => "اعرض الخريطة",
		"Route" => "الطريق",
		"Totally Jammed" => "مزدحم جداً",
		"Crowded" => "مزدحم",
		"Alright" => "معقول",
		"Great" => "رائع",
		// ..//view/listing/index/profile.phtml:155
		// ..//view/listing/index/search.phtml:242
		"Visit Website" => "الموقع الإلكتروني",
		// ..//view/listing/index/profile.phtml:162
		"Similar Businesses" => "أعمال تجارية مشابهة",
		// ..//view/listing/index/profile.phtml:167
		"About Us" => "نبذة عن الشركة",
		// ..//view/listing/index/profile.phtml:172
		// ..//view/listing/index/profile.phtml:196
		// ..//view/listing/index/profile.phtml:290
		// ..//view/listing/index/profile.phtml:358
		// ..//view/listing/index/profile.phtml:383
		"More" => "المزيد",
		// ..//view/listing/index/profile.phtml:175
		// ..//view/listing/index/profile.phtml:199
		// ..//view/listing/index/profile.phtml:296
		// ..//view/listing/index/profile.phtml:361
		// ..//view/listing/index/profile.phtml:386
		"Less" => "أقل",
		// ..//view/listing/index/profile.phtml:181
		"Photo" => "صور",
		// ..//view/listing/index/profile.phtml:207
		// ..//view/listing/index/search.phtml:223
		"Reviews" => "تعليق",
		// ..//view/listing/index/profile.phtml:217
		// ..//view/listing/index/profile.phtml:229
		"Rating" => "تقييمات",
		// ..//view/listing/index/profile.phtml:261
		"Video" => "فيديو",
		// ..//view/listing/index/profile.phtml:284
		"Company Profile" => "البيانات الشخصية",
		// ..//view/listing/index/profile.phtml:307
		"Printed Ad" => "الإعلان المطبوع",
		// ..//view/listing/index/profile.phtml:322
		"Branches" => "الفروع",
		// ..//view/listing/index/profile.phtml:334
		"Brands" => "علامات تجارية",
		// ..//view/listing/index/profile.phtml:368
		"Menu" => "قائمة الطعام",
		// ..//view/listing/index/profile.phtml:405
		"Email Us" => "البريد الإلكتروني",
		// ..//view/listing/index/profile.phtml:416
		"Sent Sucessfully." => "تم الارسال بنجاح",
		// ..//view/listing/index/profile.phtml:419
		"Send an email to this business listing for more information." => "ارسل رسالة إلى هذه الشركة للحصول على المزيد من المعلومات",
		// ..//view/listing/index/profile.phtml:426
		"Your Name" => "الإسم",
		// ..//view/listing/index/profile.phtml:433
		"Your Email Address" => "البريد الإلكتروني",
		// ..//view/listing/index/profile.phtml:442
		"Your Message" => "الرسالة ",
		// ..//view/listing/index/profile.phtml:453
		"For authenticity, please enter the code shown below" => " برجاء إدخال الكود الظاهر أمامك ",
		// ..//view/listing/index/profile.phtml:466
		"Post" => "أرسل",
		// ..//view/listing/index/profile.phtml:478
		"Email & share this result" => "ارسل هذه النتيجه",
		// ..//view/listing/index/profile.phtml:495
		// ..//view/listing/index/search.phtml:314
		// ..//view/listing/index/search.phtml:329
		"Are you statisfied" => "",
		// ..//view/listing/index/profile.phtml:499
		// ..//view/listing/index/search.phtml:322
		"Start Now" => "ابدأ الآن",
		// ..//view/listing/index/profile.phtml:538
		"Please enter your Full Name." => "رجاء إدخال الإسم",
		// ..//view/listing/index/profile.phtml:541
		// ..//view/listing/index/profile.phtml:542
		"Please enter a valid email address." => "<br>برجاء إدخال بريد إلكتروني صحيح",
		// ..//view/listing/index/profile.phtml:545
		"Please enter a Message." => "برجاء ادخال الرسالة",
		// ..//view/listing/index/profile.phtml:548
		"Please enter Code." => "برجاء إدخال الكود الظاهر أمامك",
		// ..//view/listing/index/search-form.phtml:13
		"enter_key" => "برجاء إدخال كلمة البحث",
		// ..//view/listing/index/search-form.phtml:13
		"please_enter_minimum" => "برجاء ادخال كلمة بحث تتكون من 2 احرف على الاقل ",
		// ..//view/listing/index/search-form.phtml:35
		"search" => "ابحث",
		// ..//view/listing/index/search.phtml:16
		"by_brand" => "العلامة التجارية",
		// ..//view/listing/index/search.phtml:20
		"by_category" => "التصنيف",
		// ..//view/listing/index/search.phtml:127
		"Search Results for" => "نتائج البحث عن",
		// ..//view/listing/index/search.phtml:129
		"in" => "في",
		// ..//view/listing/index/search.phtml:132
		"Showing" => "اظهار",
		// ..//view/listing/index/search.phtml:132
		"of" => "من",
		// ..//view/listing/index/search.phtml:132
		"results" => "نتائج",
		// ..//view/listing/index/search.phtml:136
		"found_in_other_areas" => "تم العثور على نتائج لـ %s فى مناطق أخرى. من فضلك %s لمشاهدة نتائج البحث.",
		// ..//view/listing/index/search.phtml:136
		"click_here" => "اضغط هنا",
		// ..//view/listing/index/search.phtml:146
		"Category Sponsor" => "راعي التصنيف",
		// ..//view/listing/index/search.phtml:219
		"Dalili Rating" => "تقييمات على دليلي",
		// ..//view/listing/index/search.phtml:221
		"Dalili Reviews" => "الآراء على دليلي",
		// ..//view/listing/index/search.phtml:281
		"keywords2" => "كلمة بحث:",
		// ..//view/listing/index/search.phtml:331
		"Sure" => "نعم",
		// ..//view/listing/index/search.phtml:332
		"Later" => "لاحقا",
		// ..//view/listing/services/opening_hours.phtml:10
		"Open24/7" => "مفتوح 24/7",
		// ..//view/listing/services/opening_hours.phtml:11
		"Cant_get_your_location" => " نعتذر، لم نتمكن من تحديد مكانك. برجاء إعادة محاولة استخدام خاصية 'البحث بالقرب منك' في وقت لاحق.",
		// ..//view/listing/services/opening_hours.phtml:12
		"Sponsored_Ads" => "إعلانات متميزة",
		// ..//view/listing/services/send-email.phtml:17
		"yourname" => "الإسم",
		// ..//view/listing/services/send-email.phtml:18
		// ..//view/listing/survey/rate-survey.phtml:41
		"email" => "البريد الإلكتروني",
		// ..//view/listing/services/send-email.phtml:19
		"your_mess" => "الرسالة",
		// ..//view/listing/services/send-email.phtml:20
		"post" => "ارسل",
		// ..//view/listing/services/send-email.phtml:23
		// ..//view/listing/services/send-email.phtml:57
		"please_enter_name" => "برجاء إدخال الإسم.",
		// ..//view/listing/services/send-email.phtml:24
		// ..//view/listing/services/send-email.phtml:62
		"please_enter_email" => "برجاء إدخال عنوان بريد اليكتروني صحيح.",
		// ..//view/listing/services/send-email.phtml:25
		// ..//view/listing/services/send-email.phtml:71
		"please_enter_message" => "برجاء إدخال الرسالة.",
		// ..//view/listing/services/send-email.phtml:26
		// ..//view/listing/services/send-email.phtml:63
		"please_enter_valid_email" => "<br>برجاء إدخال بريد إلكتروني صحيح.",
		// ..//view/listing/services/send-email.phtml:27
		"please_enter_name_min" => "ادخل الإسم بشكل صحيح.",
		// ..//view/listing/services/send-email.phtml:28
		"msg_succ" => "لقد تم إرسال الرسالة بنجاح",
		// ..//view/listing/survey/add-rating-new.phtml:21
		"Thanks for taking part in this short survey; YOUR responses will help us improve YOUR user experience." => "",
		// ..//view/listing/survey/add-rating-new.phtml:78
		"we really appreciate you helping us serve you better. Thanks!" => "",
		// ..//view/listing/survey/rate-survey.phtml:30
		"rate_heading" => "هل يمكنك مساعدتنا في جعل تجربة المستخدم غنية عن طريق الإجابة على هذه الأسئلة؟",
		// ..//view/listing/survey/rate-survey.phtml:33
		"name" => "الإسم",
		// ..//view/listing/survey/rate-survey.phtml:60
		"add_suggestions" => "هل لديك اقتراحات أو أي شيء تريد إعلامنا به؟ برجاء إضافته هنا",
		// ..//view/listing/survey/rate-survey.phtml:65
		"rate_thanks" => "نحن نقدر مساعدتكم لنا حتى نخدمكم بشكل أفضل. شكرا!",
		// ..//view/listing/survey/rate-survey.phtml:69
		"please_enter" => "برجاء إدخال الكود الظاهر أمامك."
		
		/*//~ "Yes",//~ msgstr "نعم",
		//~ "No",//~ msgstr "لا",
		//~ "maintitle",//~ msgstr "Saudi Arabia's Directory",
		//~ "Are you satisfied with results of your search today?",//~ msgstr "هل انت راضي عن نتائج البحث اليوم?",
		//~ "Categorie(s)",//~ msgstr "النشاط التجاري:",
		//~ "profile_meta_desc",//~ msgstr "",//~ "{company_name} في {areaname}, {cityname}. إبحث عن  تقييمات  ",//~ "{company_name}، المعلومات ، تفاصيل الإتصال ،  {categories} والمزيد في ",//~ "Daleeli.com",
		//~ "profile_meta_key",//~ msgstr "",//~ "{categories}, {phone_numbers}, {areaname}, {cityname}, {company_name} ",//~ "التقييمات ، المعلومات ، تفاصيل الإتصال ، رقم الهاتف ،  , {keywords} دليل ",//~ "المملكة العربية السعودية ، الدليل التجاري على الإنترنت",
		//~ "country1",//~ msgstr "السعودية",
		//~ "egyptcountry",//~ msgstr "مصر",
		//~ "cat_meta_keyword",//~ msgstr "",//~ "{category_name}, {extra} ,{location_name} ،{category_name} سعودي ،  ",//~ "الإدراجات التجارية ، الأعمال التجارية المحلية ، دليلي ، الدليل التجاري ،  ",//~ "{category_name} أعمال تجارية ، عناوين ، أرقام هواتف ، الدليل على ",//~ "الإنترنت ، التعاريف ، مقدمي الخدمة ، المتعهدين ، الموردين.",
		//~ "cat_meta_desc",//~ msgstr "",//~ "{category_name}  في  {location_name} {extra} - البحث عن اسم ",//~ "{category_name}قوائم الشركات والعناوين وأرقام الهاتف ، وتقييمات ومعلومات ",//~ "كاملة. Daleeli.com هو Daleeli الرسمية ، دليل الأعمال والسكان المحليين في ",//~ "محرك البحث.",
		//~ "to_call",//~ msgstr "...to call>>",)*/
);