<?php
return array(
		"plz" => "Please enter",
		// : ..//src/Listing/Controller/IndexController.php:1255
		"Try Again later." => "",
		// : ..//src/Listing/Controller/IndexController.php:1299
		// : ..//src/Listing/Controller/SurveyController.php:108
		"valid" => "a valid",
		// : ..//src/Listing/Controller/IndexController.php:1299
		// : ..//src/Listing/Controller/SurveyController.php:108
		"code" => "Code",
		// : ..//src/Listing/Controller/IndexController.php:1299
		// : ..//src/Listing/Controller/SurveyController.php:108
		"shown" => "shown below.",
		// : ..//src/Listing/Controller/IndexController.php:1806
		// : ..//src/Listing/Form/AddIncorrectDataReportForm.php:21
		"Telephone number" => "Telephone Number",
		// : ..//src/Listing/Controller/IndexController.php:1808
		// : ..//src/Listing/Form/AddIncorrectDataReportForm.php:28
		"Address" => "",
		// : ..//src/Listing/Controller/IndexController.php:1810
		// : ..//src/Listing/Form/AddIncorrectDataReportForm.php:35
		"Company Name" => "",
		// : ..//src/Listing/Controller/IndexController.php:1812
		// : ..//src/Listing/Form/AddIncorrectDataReportForm.php:42
		"Website" => "Website",
		// : ..//src/Listing/Controller/IndexController.php:1814
		// : ..//src/Listing/Form/AddIncorrectDataReportForm.php:49
		"Map" => "",
		// : ..//src/Listing/Controller/IndexController.php:1816
		"Closed" => "Closed",
		// : ..//src/Listing/Controller/IndexController.php:1818
		// : ..//src/Listing/Form/AddIncorrectDataReportForm.php:63
		// : ..//src/Listing/Form/AddRatingNewForm.php:30
		"Other" => "",
		// : ..//src/Listing/Controller/IndexController.php:1820
		// : ..//view/listing/index/add-incorrect-data-report.phtml:112
		"You should select one at least." => "",
		// : ..//src/Listing/Controller/IndexController.php:1838
		"Added Successfully" => "Sent Successfully.",
		// : ..//src/Listing/Controller/IndexController.php:1840
		"Operation Failed" => "",
		// : ..//src/Listing/Controller/SurveyController.php:94
		"emailalert" => "a valid Email Address",
		// : ..//src/Listing/Controller/SurveyController.php:101
		"plz_reg" => "Please select Reason",
		// : ..//src/Listing/Controller/SurveyController.php:119
		"rate_sent_succ" => "",
		"Thank you for your valuable feedback! <br>Should you require a reply from us, we will get back to you as quickly as possible. <br>We look forward to hearing from you again.",
		// : ..//src/Listing/Form/AddIncorrectDataReportForm.php:56
		"Business is closed" => " Business is closed ",
		// : ..//src/Listing/Form/AddIncorrectDataReportForm.php:70
		"",
		"If you have anything else you would like to let us know about, please do, right here:" => "",
		// : ..//src/Listing/Form/AddIncorrectDataReportForm.php:75
		// : ..//src/Listing/Form/AddRatingNewForm.php:129
		"submit" => "Submit",
		// : ..//src/Listing/Form/AddRatingNewForm.php:25
		"Today, I was searching on Yellow.com.eg for:" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:26
		// : ..//src/Listing/Form/AddRatingNewForm.php:39
		// : ..//src/Listing/Form/AddRatingNewForm.php:52
		// : ..//src/Listing/Form/AddRatingNewForm.php:65
		// : ..//src/Listing/Form/AddRatingNewForm.php:78
		// : ..//src/Listing/Form/AddRatingNewForm.php:91
		// : ..//src/Listing/Form/AddRatingNewForm.php:104
		"1" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:26
		"A product (e.g. Air Conditioners, Cars, TVs...)" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:27
		// : ..//src/Listing/Form/AddRatingNewForm.php:40
		// : ..//src/Listing/Form/AddRatingNewForm.php:53
		// : ..//src/Listing/Form/AddRatingNewForm.php:66
		// : ..//src/Listing/Form/AddRatingNewForm.php:79
		// : ..//src/Listing/Form/AddRatingNewForm.php:92
		// : ..//src/Listing/Form/AddRatingNewForm.php:105
		"2" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:27
		"A service (e.g. Food Delivery, Car Rentals, Advertising Agencies...)" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:28
		// : ..//src/Listing/Form/AddRatingNewForm.php:41
		// : ..//src/Listing/Form/AddRatingNewForm.php:54
		// : ..//src/Listing/Form/AddRatingNewForm.php:67
		// : ..//src/Listing/Form/AddRatingNewForm.php:80
		// : ..//src/Listing/Form/AddRatingNewForm.php:93
		// : ..//src/Listing/Form/AddRatingNewForm.php:106
		"3" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:28
		"A brand (e.g. Nokia, Toyota, Nike ...)" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:29
		// : ..//src/Listing/Form/AddRatingNewForm.php:42
		// : ..//src/Listing/Form/AddRatingNewForm.php:55
		// : ..//src/Listing/Form/AddRatingNewForm.php:68
		// : ..//src/Listing/Form/AddRatingNewForm.php:81
		// : ..//src/Listing/Form/AddRatingNewForm.php:94
		// : ..//src/Listing/Form/AddRatingNewForm.php:107
		"4" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:29
		"A business or Company Name (e.g. Mobinil, AUC, Andrea’s Restaurant...)" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:30
		// : ..//src/Listing/Form/AddRatingNewForm.php:43
		// : ..//src/Listing/Form/AddRatingNewForm.php:56
		// : ..//src/Listing/Form/AddRatingNewForm.php:69
		// : ..//src/Listing/Form/AddRatingNewForm.php:82
		// : ..//src/Listing/Form/AddRatingNewForm.php:95
		// : ..//src/Listing/Form/AddRatingNewForm.php:108
		"5" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:38
		"Overall, my experience on Yellow.com.eg was good. " => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:39
		// : ..//src/Listing/Form/AddRatingNewForm.php:52
		// : ..//src/Listing/Form/AddRatingNewForm.php:65
		// : ..//src/Listing/Form/AddRatingNewForm.php:78
		// : ..//src/Listing/Form/AddRatingNewForm.php:91
		// : ..//src/Listing/Form/AddRatingNewForm.php:104
		"Strongly Agree" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:40
		// : ..//src/Listing/Form/AddRatingNewForm.php:53
		// : ..//src/Listing/Form/AddRatingNewForm.php:66
		// : ..//src/Listing/Form/AddRatingNewForm.php:79
		// : ..//src/Listing/Form/AddRatingNewForm.php:92
		// : ..//src/Listing/Form/AddRatingNewForm.php:105
		"Agree" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:41
		// : ..//src/Listing/Form/AddRatingNewForm.php:54
		// : ..//src/Listing/Form/AddRatingNewForm.php:67
		// : ..//src/Listing/Form/AddRatingNewForm.php:80
		// : ..//src/Listing/Form/AddRatingNewForm.php:93
		// : ..//src/Listing/Form/AddRatingNewForm.php:106
		"Neutral" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:42
		// : ..//src/Listing/Form/AddRatingNewForm.php:55
		// : ..//src/Listing/Form/AddRatingNewForm.php:68
		// : ..//src/Listing/Form/AddRatingNewForm.php:81
		// : ..//src/Listing/Form/AddRatingNewForm.php:94
		// : ..//src/Listing/Form/AddRatingNewForm.php:107
		"Disagree" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:43
		// : ..//src/Listing/Form/AddRatingNewForm.php:56
		// : ..//src/Listing/Form/AddRatingNewForm.php:69
		// : ..//src/Listing/Form/AddRatingNewForm.php:82
		// : ..//src/Listing/Form/AddRatingNewForm.php:95
		// : ..//src/Listing/Form/AddRatingNewForm.php:108
		"Strongly Disagree" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:51
		"It was easy to find what I was looking for on Yellow.com.eg." => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:64
		"I will take the next step and contact the company I found on Yellow.com.eg today or within one week." => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:77
		"The number of companies I'll contact from those I found on Yellow.com.eg are:" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:90
		"When I'm searching for a business on Yellow.com.eg, it is important to me that the companies I look at have (check all that apply):" => "",
		// : ..//src/Listing/Form/AddRatingNewForm.php:103
		"In continuation of the above question, I would rarely contact a company if it only provides a phone number without any other information about it." => "",
		// : ..//src/Listing/Helper/AlsoServing.php:26
		// : ..//src/Listing/Helper/AlsoServing.php:30
		"also_serving" => "... Also Serving",
		// : ..//src/Listing/Helper/AreaBox.php:87
		// : ..//view/listing/index/character-bar-search.phtml:14
		// : ..//view/listing/index/character-bar.phtml:14
		// : ..//view/listing/index/search-form.phtml:21
		// : ..//view/listing/index/search-form.phtml:23
		"all" => "All",
		// : ..//src/Listing/Helper/AreaBox.php:103
		"close" => "Close",
		// : ..//src/Listing/Helper/AreaBox.php:107
		// : ..//view/listing/index/search.phtml:77
		"more" => "More&nbsp;>>",
		// : ..//src/Listing/Helper/CompanyAddress.php:58
		// : ..//view/listing/index/ksa_search.phtml:110
		// : ..//view/listing/index/ksa_search.phtml:238
		"landmark" => "Landmark",
		// : ..//src/Listing/Helper/CompanyContacts.php:76
		"companyphone" => "Phone",
		// : ..//src/Listing/Helper/CompanyContacts.php:79
		"fax" => "Fax",
		// : ..//src/Listing/Helper/CompanyContacts.php:82
		"phoneFax" => "Telefax",
		// : ..//src/Listing/Helper/CompanyOpeningHours.php:49
		"Open 24/7" => "Open 24/7",
		// : ..//src/Listing/Helper/CompanyServices.php:38
		// : ..//src/Listing/Helper/ServicesBar.php:75
		"photoicon" => "Photo",
		// : ..//src/Listing/Helper/CompanyServices.php:44
		"reviews" => "Reviews",
		// : ..//src/Listing/Helper/CompanyServices.php:54
		// : ..//src/Listing/Helper/ServicesBar.php:67
		"videoicon" => "Video",
		// : ..//src/Listing/Helper/CompanyServices.php:60
		// : ..//src/Listing/Helper/ServicesBar.php:71
		"profileicon" => "Profile",
		// : ..//src/Listing/Helper/CompanyServices.php:66
		// : ..//src/Listing/Helper/ServicesBar.php:79
		"adicon" => "Printed Ad",
		// : ..//src/Listing/Helper/CompanyServices.php:78
		// : ..//src/Listing/Helper/ServicesBar.php:63
		"brandicon" => "Brands",
		// : ..//src/Listing/Helper/CompanyServices.php:84
		"menuicon" => "Menu",
		// : ..//src/Listing/Helper/CompanyServices.php:90
		// : ..//view/listing/index/profile.phtml:392
		"our_restaurants" => "Our Restaurants",
		// : ..//src/Listing/Helper/ServicesBar.php:47
		"qricon" => "QR Code",
		// : ..//src/Listing/Helper/ServicesBar.php:51
		"emailicon" => "Email",
		// : ..//src/Listing/Helper/ServicesBar.php:55
		"websiteicon" => "Website",
		// : ..//src/Listing/Helper/ServicesBar.php:59
		"branchicon" => "Branches",
		// : ..//src/Listing/Helper/SocialLinks.php:36
		"My \".tel\" Page" => "",
		// : ..//src/Listing/Helper/SocialLinks.php:39
		// : ..//src/Listing/Helper/SocialLinks.php:42
		"My \"Facebook\" Page" => "",
		// : ..//src/Listing/Helper/SocialLinks.php:45
		"Follow us on Twitter" => "",
		// : ..//src/Listing/Helper/SocialLinks.php:48
		"Follow us on Google+" => "",
		// : ..//src/Listing/Helper/SocialLinks.php:51
		"My \"Linked In\" Page" => "",
		// : ..//src/Listing/Helper/SocialLinks.php:54
		"My Video Link on YouTube" => "My Channel on YouTube",
		// : ..//src/Listing/Helper/SocialLinks.php:57
		// : ..//src/Listing/Helper/SocialLinks.php:60
		"My Business Online" => "My Business Online",
		// : ..//src/Listing/Helper/WorkingDaysAndHours.php:46
		"am" => "am",
		// : ..//src/Listing/Helper/WorkingDaysAndHours.php:48
		"pm" => "pm",
		// : ..//view/listing/index/boxes.phtml:8
		// : ..//view/listing/index/keyword-search.phtml:10
		"relatedkey" => "Related Keywords",
		// : ..//view/listing/index/boxes.phtml:23
		// : ..//view/listing/index/category-search.phtml:10
		// : ..//view/listing/index/search.phtml:117
		"relatedcat" => "Related Categories",
		// : ..//view/listing/index/boxes.phtml:39
		// : ..//view/listing/index/brand-search.phtml:11
		// : ..//view/listing/index/search.phtml:108
		"relatedbrands" => "Related Brands ",
		// : ..//view/listing/index/directions.phtml:201
		"Totally Jammed" => "",
		// : ..//view/listing/index/directions.phtml:205
		"Crowded" => "",
		// : ..//view/listing/index/directions.phtml:209
		"Alright" => "",
		// : ..//view/listing/index/directions.phtml:213
		"Great" => "",
		// : ..//view/listing/index/directions.phtml:217
		"Route" => "",
		// : ..//view/listing/index/ksa_search.phtml:55
		"searchresultsfor" => "Search Results for",
		// : ..//view/listing/index/ksa_search.phtml:57
		"searchreturns" => "returns",
		// : ..//view/listing/index/ksa_search.phtml:57
		"searchlistings" => "listings",
		// : ..//view/listing/index/ksa_search.phtml:61
		"mapselectedlistings" => "Show All Results on Map",
		// : ..//view/listing/index/ksa_search.phtml:63
		// : ..//view/listing/index/ksa_search.phtml:346
		"sendSearchResult" => "Share Results",
		// : ..//view/listing/index/ksa_search.phtml:82
		"categorysponsor" => "Category Sponsor",
		// : ..//view/listing/index/ksa_search.phtml:84
		"keywordsponsor" => "Keyword Sponsor",
		// : ..//view/listing/index/ksa_search.phtml:121
		// : ..//view/listing/index/ksa_search.phtml:249
		"pobox" => "P.O.Box",
		// : ..//view/listing/index/ksa_search.phtml:124
		// : ..//view/listing/index/ksa_search.phtml:252
		"postalcode" => "Postal Code",
		// : ..//view/listing/index/ksa_search.phtml:138
		// : ..//view/listing/index/ksa_search.phtml:266
		// : ..//view/listing/index/search.phtml:198
		"read_more" => "Read More >>",
		// : ..//view/listing/index/ksa_search.phtml:155
		// : ..//view/listing/index/ksa_search.phtml:283
		// : ..//view/listing/index/profile.phtml:69
		// : ..//view/listing/index/search.phtml:285
		"categories" => "Categories:",
		// : ..//view/listing/index/ksa_search.phtml:167
		// : ..//view/listing/index/ksa_search.phtml:295
		"updateData" => "Update Data",
		// : ..//view/listing/index/ksa_search.phtml:173
		// : ..//view/listing/index/ksa_search.phtml:301
		"keyword" => "Keyword",
		// : ..//view/listing/index/ksa_search.phtml:197
		// : ..//view/listing/index/ksa_search.phtml:325
		"sendListing" => "Share Listing",
		// : ..//view/listing/index/profile.phtml:61
		// : ..//view/listing/index/search.phtml:186
		"See All Branches" => "",
		// : ..//view/listing/index/profile.phtml:74
		"Payment Method" => "",
		// : ..//view/listing/index/profile.phtml:107
		// : ..//view/listing/index/search.phtml:268
		"Order Now" => "",
		// : ..//view/listing/index/profile.phtml:116
		// : ..//view/listing/index/profile.phtml:121
		// : ..//view/listing/services/opening_hours.phtml:3
		"Sunday" => "Sun",
		// : ..//view/listing/index/profile.phtml:117
		// : ..//view/listing/services/opening_hours.phtml:4
		"Monday" => "Mon",
		// : ..//view/listing/index/profile.phtml:118
		// : ..//view/listing/services/opening_hours.phtml:5
		"Tuesday" => "Tue",
		// : ..//view/listing/index/profile.phtml:119
		// : ..//view/listing/services/opening_hours.phtml:6
		"Wednesday" => "Wed",
		// : ..//view/listing/index/profile.phtml:120
		// : ..//view/listing/services/opening_hours.phtml:7
		"Thursday" => "Thu",
		// : ..//view/listing/index/profile.phtml:122
		// : ..//view/listing/services/opening_hours.phtml:8
		"Friday" => "Fri",
		// : ..//view/listing/index/profile.phtml:123
		// : ..//view/listing/services/opening_hours.phtml:9
		"Saturday" => "Sat",
		// : ..//view/listing/index/profile.phtml:132
		// : ..//view/listing/index/search.phtml:292
		"What was incorrect in the business listing" => "What was incorrect in the business listing?",
		// : ..//view/listing/index/profile.phtml:132
		// : ..//view/listing/index/search.phtml:292
		"Report incorrect data" => "",
		// : ..//view/listing/index/profile.phtml:146
		// : ..//view/listing/index/search.phtml:233
		"To Call" => "",
		// : ..//view/listing/index/profile.phtml:149
		// : ..//view/listing/index/search.phtml:236
		"Contact Us" => "",
		// : ..//view/listing/index/profile.phtml:152
		// : ..//view/listing/index/search.phtml:239
		"Get Directions" => "",
		"Route" => "Route",
		"Totally Jammed" => "Totally Jammed",
		"Crowded" => "Crowded",
		"Alright" => "Alright",
		"Great" => "Great",
		// : ..//view/listing/index/profile.phtml:155
		// : ..//view/listing/index/search.phtml:242
		"Visit Website" => "",
		// : ..//view/listing/index/profile.phtml:162
		"Similar Businesses" => "Similar Businesses",
		// : ..//view/listing/index/profile.phtml:167
		"About Us" => "",
		// : ..//view/listing/index/profile.phtml:172
		// : ..//view/listing/index/profile.phtml:196
		// : ..//view/listing/index/profile.phtml:290
		// : ..//view/listing/index/profile.phtml:358
		// : ..//view/listing/index/profile.phtml:383
		"More" => "",
		// : ..//view/listing/index/profile.phtml:175
		// : ..//view/listing/index/profile.phtml:199
		// : ..//view/listing/index/profile.phtml:296
		// : ..//view/listing/index/profile.phtml:361
		// : ..//view/listing/index/profile.phtml:386
		"Less" => "",
		// : ..//view/listing/index/profile.phtml:181
		"Photo" => "Photos",
		// : ..//view/listing/index/profile.phtml:207
		// : ..//view/listing/index/search.phtml:223
		"Reviews" => "Reviews",
		// : ..//view/listing/index/profile.phtml:217
		// : ..//view/listing/index/profile.phtml:229
		"Rating" => "Ratings",
		// : ..//view/listing/index/profile.phtml:261
		"Video" => "Video",
		// : ..//view/listing/index/profile.phtml:284
		"Company Profile" => "",
		// : ..//view/listing/index/profile.phtml:307
		"Printed Ad" => "",
		// : ..//view/listing/index/profile.phtml:322
		"Branches" => "",
		// : ..//view/listing/index/profile.phtml:334
		"Brands" => "",
		// : ..//view/listing/index/profile.phtml:368
		"Menu" => "",
		// : ..//view/listing/index/profile.phtml:405
		"Email Us" => "Your Email",
		// : ..//view/listing/index/profile.phtml:416
		"Sent Sucessfully." => "Sent Sucessfully.",
		// : ..//view/listing/index/profile.phtml:419
		"Send an email to this business listing for more information." => "Send an email to this business listing for more information.",
		// : ..//view/listing/index/profile.phtml:426
		"Your Name" => "",
		// : ..//view/listing/index/profile.phtml:433
		"Your Email Address" => "",
		// : ..//view/listing/index/profile.phtml:442
		"Your Message" => "",
		// : ..//view/listing/index/profile.phtml:453
		"For authenticity, please enter the code shown below" => "",
		// : ..//view/listing/index/profile.phtml:466
		"Post" => "Send",
		// : ..//view/listing/index/profile.phtml:478
		"Email & share this result" => "Email and Share this Result",
		// : ..//view/listing/index/profile.phtml:495
		// : ..//view/listing/index/search.phtml:314
		// : ..//view/listing/index/search.phtml:329
		"Are you statisfied" => "Could you kindly participate in our 1 min. survey to rate your overall experience on <b>Yellow.com.eg</b>?",
		// : ..//view/listing/index/profile.phtml:499
		// : ..//view/listing/index/search.phtml:322
		"Start Now" => "",
		// : ..//view/listing/index/profile.phtml:538
		"Please enter your Full Name." => "",
		// : ..//view/listing/index/profile.phtml:541
		// : ..//view/listing/index/profile.phtml:542
		"Please enter a valid email address." => "Please enter a valid Email Address.",
		// : ..//view/listing/index/profile.phtml:545
		"Please enter a Message." => "Please enter a valid Message.",
		// : ..//view/listing/index/profile.phtml:548
		"Please enter Code." => "Please enter Code.",
		// : ..//view/listing/index/search-form.phtml:13
		"enter_key" => "Please enter Keyword!",
		// : ..//view/listing/index/search-form.phtml:13
		"please_enter_minimum" => "Please enter a Keyword of minimum 2 characters!",
		// : ..//view/listing/index/search-form.phtml:35
		"search" => "Search",
		// : ..//view/listing/index/search.phtml:16
		"by_brand" => "Brands",
		// : ..//view/listing/index/search.phtml:20
		"by_category" => "Category",
		// : ..//view/listing/index/search.phtml:127
		"Search Results for" => "Search Results for",
		// : ..//view/listing/index/search.phtml:129
		"in" => "in",
		// : ..//view/listing/index/search.phtml:132
		"Showing" => "",
		// : ..//view/listing/index/search.phtml:132
		"of" => "",
		// : ..//view/listing/index/search.phtml:132
		"results" => "Results",
		// : ..//view/listing/index/search.phtml:136
		"found_in_other_areas" => "We have found results for %s  in other location(s). Please %s  to see search results.",
		// : ..//view/listing/index/search.phtml:136
		"click_here" => "click here",
		// : ..//view/listing/index/search.phtml:146
		"Category Sponsor" => "Category Sponsor",
		// : ..//view/listing/index/search.phtml:219
		"Dalili Rating" => "Dalili Ratings",
		// : ..//view/listing/index/search.phtml:221
		"Dalili Reviews" => "",
		// : ..//view/listing/index/search.phtml:281
		"keywords2" => "Keywords:",
		// : ..//view/listing/index/search.phtml:331
		"Sure" => "",
		// : ..//view/listing/index/search.phtml:332
		"Later" => "",
		// : ..//view/listing/services/opening_hours.phtml:10
		"Open24/7" => "Open 24/7",
		// : ..//view/listing/services/opening_hours.phtml:11
		"Cant_get_your_location" => "We're sorry, but we can't locate your location right now. Please try the 'Nearby Search' again later. ",
		// : ..//view/listing/services/opening_hours.phtml:12
		"Sponsored_Ads" => "Sponsored Ads",
		// : ..//view/listing/services/send-email.phtml:17
		"yourname" => "Your Name",
		// : ..//view/listing/services/send-email.phtml:18
		// : ..//view/listing/survey/rate-survey.phtml:41
		"email" => "Your Email",
		// : ..//view/listing/services/send-email.phtml:19
		"your_mess" => "Your Message",
		// : ..//view/listing/services/send-email.phtml:20
		"post" => "Send",
		// : ..//view/listing/services/send-email.phtml:23
		// : ..//view/listing/services/send-email.phtml:57
		"please_enter_name" => "Please enter Name",
		// : ..//view/listing/services/send-email.phtml:24
		// : ..//view/listing/services/send-email.phtml:62
		"please_enter_email" => "Please enter a valid Email Address",
		// : ..//view/listing/services/send-email.phtml:25
		// : ..//view/listing/services/send-email.phtml:71
		"please_enter_message" => "Please enter a valid Message",
		// : ..//view/listing/services/send-email.phtml:26
		// : ..//view/listing/services/send-email.phtml:63
		"please_enter_valid_email" => "Please enter a valid Email Address",
		// : ..//view/listing/services/send-email.phtml:27
		"please_enter_name_min" => "Please enter name of at least 2 characters.",
		// : ..//view/listing/services/send-email.phtml:28
		"msg_succ" => "Message Sent Successfully",
		// : ..//view/listing/survey/add-rating-new.phtml:21
		"Thanks for taking part in this short survey; YOUR responses will help us ",
		"improve YOUR user experience." => "Thanks for taking part in this short survey; YOUR responses will help us improve YOUR user experience.",
		// : ..//view/listing/survey/add-rating-new.phtml:78
		"we really appreciate you helping us serve you better. Thanks!" => "We really appreciate you helping us serve you better. Thanks!",
		// : ..//view/listing/survey/rate-survey.phtml:30
		"rate_heading" => "Could you please help us make your user experience even richer by answering these questions?",
		// : ..//view/listing/survey/rate-survey.phtml:33
		"name" => "Name",
		// : ..//view/listing/survey/rate-survey.phtml:60
		"add_suggestions" => "If you have anything else you would like to let us know about, please do, right here:",
		// : ..//view/listing/survey/rate-survey.phtml:65
		"rate_thanks" => "We really appreciate you helping us serve you better. Thanks!",
		// : ..//view/listing/survey/rate-survey.phtml:69
		"please_enter" => "For authenticity, please enter the code shown below"
		// , fuzzy
		// ~ "businesses",//~ msgstr "My Business Online",
		// ~ "maintitle",//~ msgstr "Yellow.com.eg",
		// ~ "more_brands",//~ msgstr "More Brands",
		// ~ "single_brand",//~ msgstr "brand",
		// , fuzzy
		// ~ "Categorie(s)",//~ msgstr "Category(s):",
		// ~ "profile_meta_desc",//~ msgstr "",//~ "{company_name} in {area name}, {city
		// name}. Find {company_name} ratings, ",//~ "information, contact details,
		// {categories} and more at Daleeli.com",
		// ~ "profile_meta_key",//~ msgstr "",//~ "{company_name}, {areaname},
		// {cityname}, {phone_numbers}, {categories} ",//~ "rating, information, contact
		// details, telephone number, {keywords}, saudi ",//~ "arabia directory, online
		// business directory",
		// ~ "country1",//~ msgstr "Saudi Arabia",
		// ~ "egyptcountry",//~ msgstr "Egypt",
		// ~ "cat_meta_keyword",//~ msgstr "",//~ "{category_name} {location_name},
		// {extra}, {category_name} saudi, business ",//~ "listings, local businesses,
		// Daleeli, business directory, {category_name} ",//~ "businesses, addresses,
		// telephone numbers, online directory, profiles, ",//~ "service providers,
		// dealers, suppliers",
		// ~ "cat_meta_desc",//~ msgstr "",//~ "{category_name} in {location_name}
		// {extra} - Search for {category_name} ",//~ "business listings, addresses,
		// telephone numbers, ratings and complete ",//~ "information. Daleeli.com is
		// the Official Saudi business directory & ",//~ "locals search engine.",
		// ~ "to_call",//~ msgstr "To Call",
);